using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using Runtime.Dialogue.Core;
using Runtime.Dialogue.Logic;

namespace Runtime.Dialogue.Plugins.Commands
{
    [Serializable]
    public class DirectTargetMapping
    {
        [Tooltip("�^�O�Ŏw�肷�鎯��ID�i��: CameraManager, SoundManager�j")]
        public string targetID;
        [Tooltip("�Ώۂ�GameObject")]
        public GameObject targetObject;
    }

    [HandlerInfo("�I�u�W�F�N�g�̃��\�b�h���_��Ȏw������ŌĂяo���܂�",
                 "�g����1: [call:mode=nearest,script=EnemyController,method=Attack]\n" +
                 "�g����2: [call:mode=tag,tag=Boss,method=PlayAnim,arg=Roar]\n" +
                 "�g����3: [call:mode=direct,target=CameraRig,script=CameraShake,method=Shake]")]
    public class GenericCallCommandHandler : MonoBehaviour, IDialogueCommandHandler
    {
        public string TargetCommandName => "call";

        [Header("�w�����3�p: Inspector�o�^���X�g")]
        [SerializeField] private List<DirectTargetMapping> directTargets = new List<DirectTargetMapping>();

        [Header("�w�����1�p: ��������̊�ʒu�i��Ȃ�Camera.main���g�p�j")]
        [SerializeField] private Transform referenceTransform;

        private void Start()
        {
            if (DialogueEventDispatcher.Instance != null)
            {
                DialogueEventDispatcher.Instance.RegisterHandler(this);
            }

            if (referenceTransform == null && Camera.main != null)
            {
                referenceTransform = Camera.main.transform;
            }
        }

        public void Execute(DialogueCommand command, Action onComplete)
        {
            string mode = command.GetString("mode", "direct").ToLower();
            string scriptName = command.GetString("script", "");
            string methodName = command.GetString("method", "");
            string arg = command.GetString("arg", null);

            GameObject targetObj = null;

            switch (mode)
            {
                case "nearest": // 1. �w��X�N���v�g�������Łu�ł��߂��v�I�u�W�F�N�g
                    targetObj = FindNearestObjectWithScript(scriptName);
                    break;

                case "tag": // 2. ���O�^�O�iDialogueCustomTag�j�Ŏw��
                    string customTag = command.GetString("tag", "");
                    targetObj = FindObjectByCustomTag(customTag);
                    break;

                case "direct": // 3. Inspector�o�^����w��
                default:
                    string targetID = command.GetString("target", "");
                    var mapping = directTargets.Find(t => t.targetID.Equals(targetID, StringComparison.OrdinalIgnoreCase));
                    if (mapping != null) targetObj = mapping.targetObject;
                    break;
            }

            if (targetObj != null && !string.IsNullOrEmpty(methodName))
            {
                InvokeMethod(targetObj, scriptName, methodName, arg);
            }
            else
            {
                Debug.LogWarning($"[GenericCall] �ΏۃI�u�W�F�N�g�܂��̓��\�b�h��������܂��� (Mode: {mode})");
            }

            onComplete?.Invoke();
        }

        // ����1: �A�Z���u���Q�Ƃɍ��E����Ȃ����S�ȃI�u�W�F�N�g�擾
        private GameObject FindNearestObjectWithScript(string scriptName)
        {
            if (referenceTransform == null || string.IsNullOrEmpty(scriptName)) return null;

#pragma warning disable CS0618
            var allMonoBehaviours = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>();
#pragma warning restore CS0618

            GameObject nearestObj = null;
            float minDistance = float.MaxValue;

            foreach (var mb in allMonoBehaviours)
            {
                if (mb == null) continue;

                if (mb.GetType().Name.Equals(scriptName, StringComparison.OrdinalIgnoreCase))
                {
                    float dist = Vector3.Distance(referenceTransform.position, mb.transform.position);
                    if (dist < minDistance)
                    {
                        minDistance = dist;
                        nearestObj = mb.gameObject;
                    }
                }
            }

            return nearestObj;
        }

        // ����2: �A�Z���u���Q�Ƃɍ��E����Ȃ����S�ȃ^�O����
        private GameObject FindObjectByCustomTag(string tag)
        {
            if (string.IsNullOrEmpty(tag)) return null;

#pragma warning disable CS0618
            var tags = UnityEngine.Object.FindObjectsOfType<DialogueCustomTag>();
#pragma warning restore CS0618

            foreach (var t in tags)
            {
                if (t != null && t.TagName.Equals(tag, StringComparison.OrdinalIgnoreCase))
                {
                    return t.gameObject;
                }
            }
            return null;
        }

        private void InvokeMethod(GameObject targetObj, string scriptName, string methodName, string arg)
        {
            var components = targetObj.GetComponents<MonoBehaviour>();

            foreach (var comp in components)
            {
                if (comp == null) continue;

                Type type = comp.GetType();

                if (!string.IsNullOrEmpty(scriptName) &&
                    !type.Name.Equals(scriptName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                MethodInfo method = type.GetMethod(methodName,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                if (method != null)
                {
                    var parameters = method.GetParameters();
                    if (parameters.Length == 0)
                    {
                        method.Invoke(comp, null);
                        return;
                    }
                    else if (parameters.Length == 1 && parameters[0].ParameterType == typeof(string))
                    {
                        method.Invoke(comp, new object[] { arg });
                        return;
                    }
                }
            }
        }

        public void ForceComplete(DialogueCommand command)
        {
            Execute(command, null);
        }
    }
}