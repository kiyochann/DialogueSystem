﻿using Runtime.Dialogue.Logic;
using Runtime.Dialogue.Core;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Runtime.Dialogue
{
    public class DialogueTesting : MonoBehaviour
    {
        [SerializeField] private DialogueContainer testData;
        [SerializeField] private DialogueViewWindow dialogueView;

        private void Update()
        {
            bool isAdvanceInputPressed = false;

            // スペースキーまたはエンターキーの判定
            if (Keyboard.current != null)
            {
                if (Keyboard.current.spaceKey.wasPressedThisFrame ||
                    Keyboard.current.enterKey.wasPressedThisFrame)
                {
                    isAdvanceInputPressed = true;
                }
            }

            // マウスの左クリックの判定
            if (Mouse.current != null)
            {
                if (Mouse.current.leftButton.wasPressedThisFrame)
                {
                    isAdvanceInputPressed = true;
                }
            }

            // 何らかの入力があった場合
            if (isAdvanceInputPressed)
            {
                // エラーの原因だった「WaitingForInput」を削除し、条件をシンプルにしました
                if (DialogueManager.Instance.CurrentState == DialogueState.Idle)
                {
                    // 1. 待機中なら会話を開始する
                    if (dialogueView != null)
                    {
                        DialogueManager.Instance.RegisterView(dialogueView);
                    }

                    DialogueManager.Instance.StartDialogue(testData, () => {
                        Debug.Log("【テスト】会話イベントが終了しました。");
                    });
                }
                else
                {
                    // 2. 会話中（Idle以外）なら文字送り・次のノードへ進む
                    DialogueManager.Instance.HandleAdvanceInput();
                }
            }
        }
    }
}